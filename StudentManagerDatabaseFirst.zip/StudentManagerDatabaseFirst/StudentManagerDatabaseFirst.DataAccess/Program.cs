﻿using StudentManagerDatabaseFirst.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagerDatabaseFirst.Pesentation
{
    class Program
    {
        public StudentManagerRepository repository = new StudentManagerRepository();
        static void Main(string[] args)
        {
            int operation;
            do
            {
                Program program = new Program();
                operation = GetDataAccess();
                switch (operation)
                {
                    case 1:
                        program.List();
                        break;
                    case 2:          
                        program.AddStudent();
                        break;
                    case 3:     
                        program.UpdateStudent();
                        break;
                    case 4:
                        program.DeleteStudent();
                        break;
                    default:
                        Environment.Exit(0);
                        break;
                }
            } while (operation != 5);
        }


        private static int GetDataAccess()
        {
            Console.WriteLine("What do you want to do? \n (1)  Get all students \n (2)  Add new student \n (3)  Update student \n (4)  Delete student \n (5)  Exit");
            var operation = int.Parse(Console.ReadLine());
            while (operation != 1 && operation != 2 && operation != 3 && operation != 4 && operation != 5)
            {
                Console.WriteLine("Incorrect operation, please choose again: \n (1)  Get all students \n (2)  Add new student \n (3)  Update student \n (4)  Delete student \n (5)  Exit");
                operation = int.Parse(Console.ReadLine());
            }
            return operation;
        }

        private void List()
        {
            var studentList = repository.GetAll();
            foreach (var item in studentList)
            {
                Console.WriteLine("Id: " + item.Id + "  Name: " + item.Name + "  Last Name: " + item.Lastname + "  Birthdate: " + item.Birthday + "\n");
            }
        }

        private void AddStudent()
        {
            Console.WriteLine("Name: ");
            var studentName = Console.ReadLine();
            Console.WriteLine("Last Name: ");
            var studentLastName = Console.ReadLine();
            Console.WriteLine("Birthdate (dd/mm/yyyy): ");
            var studentBirthdate = DateTime.Parse(Console.ReadLine());

            var student = new Student
            {
                Name = studentName,
                Lastname = studentLastName,
                Birthday = studentBirthdate
            };
            repository.Create(student);
        }

        private void UpdateStudent()
        {
            Console.WriteLine("Id:\n");
            var studentId = int.Parse(Console.ReadLine());
            Console.WriteLine("Name:\n");
            var studentName = Console.ReadLine();
            Console.WriteLine("Last Name:\n");
            var studentLastName = Console.ReadLine();
            Console.WriteLine("Birthdate (dd/mm/yyyy):\n");
            var studentBirthdate = DateTime.Parse(Console.ReadLine());

            var student = new Student
            {
                Id = studentId,
                Name = studentName,
                Lastname = studentLastName,
                Birthday = studentBirthdate
            };
            repository.Update(student);
        }

        private void DeleteStudent()
        {
            Console.WriteLine("Id:\n");
            var studentId = int.Parse(Console.ReadLine());
            repository.DeleteById(studentId);
        }
    }
}
