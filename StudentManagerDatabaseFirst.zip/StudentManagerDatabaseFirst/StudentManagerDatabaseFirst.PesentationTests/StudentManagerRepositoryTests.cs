﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using StudentManagerDatabaseFirst.Pesentation;
using System;
using System.Linq;

namespace StudentManagerDatabaseFirst.Presentation.Tests
{
    [TestClass]
    public class StudentManagerRepositoryTests
    {
        [ClassInitialize]
        public static void TestFixtureSetup()
        {
            var repository = new StudentManagerRepository();
            Student student1 = new Student { Id = 1, Name = "Albert", Lastname = "Riera", Birthday = DateTime.Parse("10/10/2010"), Guid = Guid.NewGuid() };
            Student student2 = new Student { Id = 2, Name = "Oscar", Lastname = "Perez", Birthday = DateTime.Parse("10/10/2010"), Guid = Guid.NewGuid() };
            Student student3 = new Student { Id = 3, Name = "fasdfasdf", Lastname = "fdsa", Birthday = DateTime.Parse("10/10/2010"), Guid = Guid.NewGuid() };
            Student student4 = new Student { Id = 4, Name = "ghhh", Lastname = "rtrr", Birthday = DateTime.Parse("10/10/2010"), Guid = Guid.NewGuid() };
            Student student5 = new Student { Id = 5, Name = "nnn", Lastname = "fgfgs", Birthday = DateTime.Parse("10/10/2010"), Guid = Guid.NewGuid() };
            repository.Create(student1);
            repository.Create(student2);
            repository.Create(student3);
            repository.Create(student4);
            repository.Create(student5);
        }

        [TestInitialize]
        public void Setup()
        {
            //dfg
        }

        [ClassCleanup]
        public static void TestFixtureTearDown()
        {
            var connection = new StudentManagerDatabaseFirstEntities();
            connection.Student.RemoveRange(connection.Student.ToList());
            connection.SaveChanges();

        }

        [TestCleanup]
        public void TearDown()
        {
            // Runs after each test. (Optional)
        }

        [TestMethod()]
        public void GetAllTest()
        {
            var repository = new StudentManagerRepository();
            var studentsList = repository.GetAll();
            Assert.IsTrue(studentsList.Count == 5);
        }

        [TestMethod()]
        public void CreateTest()
        {
            Student student6 = new Student { Id = 6, Name = "Added", Lastname = "fgfgs", Birthday = DateTime.Parse("10/10/2010"), Guid = Guid.NewGuid() };
            var repository = new StudentManagerRepository();
            repository.Create(student6);
            var studentsList = repository.GetAll();
            Assert.IsTrue(studentsList.Last().Name == "Added");
        }

        [TestMethod()]
        public void UpdateTest()
        {
            var repository = new StudentManagerRepository();
            Student updateStudent = new Student { Id = 2, Name = "updated", Lastname = "name", Birthday = DateTime.Parse("10/10/2010") };
            repository.Update(updateStudent);
            Assert.IsTrue(repository.GetAll().FirstOrDefault(x=>x.Id == 2).Name == "updated");
        }

        [TestMethod()]
        public void DeleteByIdTest()
        {
            var repository = new StudentManagerRepository();
            var id = 2;
            repository.DeleteById(id);

            Assert.IsNull(repository.GetAll().Find(x=> x.Id == 2));
        }
    }
}