﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagerDatabaseFirst
{
    class StudentManagerRepository
    {
        public List<Student> GetAll()
        {
            List<Student> studentsList = null;
            using(var database = new StudentManagerDatabaseFirstEntities())
            {
                try
                {
                    studentsList = database.Student.ToList();
                }
                catch (ArgumentNullException)
                {
                    throw;
                }
            }
            return studentsList;
        }

        public Student Create(Student student)
        {
            using(var database = new StudentManagerDatabaseFirstEntities())
            {
                try
                {
                    database.Student.Add(student);
                    database.SaveChanges();
                }catch (NotSupportedException e)
                {
                    throw;
                }
            }
            return student;
        }

        public Student Update(Student student)
        {
            Student studentToUpdate = null;
            using(var database = new StudentManagerDatabaseFirstEntities())
            {
                studentToUpdate = database.Student.FirstOrDefault(x => x.Id == student.Id);

                studentToUpdate.Name = student.Name;
                studentToUpdate.Lastname = student.Lastname;
                studentToUpdate.Birthday = student.Birthday;

                database.Student.Add(studentToUpdate);
                database.SaveChanges();
            }
            return studentToUpdate;
        }

        public Student DeleteById(int id)
        {
            Student studentToDelete = null;
            using(var database = new StudentManagerDatabaseFirstEntities())
            {
                studentToDelete = GetAll().FirstOrDefault(x=>x.Id==id);
                database.Student.Remove(studentToDelete);
            }
            return studentToDelete;
        }
    }
}
