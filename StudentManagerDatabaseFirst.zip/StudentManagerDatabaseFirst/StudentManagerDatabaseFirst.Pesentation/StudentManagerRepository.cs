﻿using StudentManagerDatabaseFirst.Pesentation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StudentManagerDatabaseFirst.Presentation
{
    public class StudentManagerRepository
    {
        public List<Student> GetAll()
        {
            List<Student> studentsList = null;
            using (var database = new StudentManagerDatabaseFirstEntities())
            {
                try
                {
                    studentsList = database.Student.ToList();
                }
                catch (ArgumentNullException)
                {
                    throw;
                }
            }
            return studentsList;
        }

        public Student Create(Student student)
        {
            using (var database = new StudentManagerDatabaseFirstEntities())
            {
                try
                {
                    database.Student.Add(student);
                    database.SaveChanges();
                }
                catch (NotSupportedException e)
                {
                    throw;
                }
            }
            return student;
        }

        public Student Update(Student student)
        {
            Student studentToUpdate = null;
            using (var database = new StudentManagerDatabaseFirstEntities())
            {
                studentToUpdate = database.Student.Where(x => x.Id == student.Id).FirstOrDefault();

                studentToUpdate.Name = student.Name;
                studentToUpdate.Lastname = student.Lastname;
                studentToUpdate.Birthday = student.Birthday;

                database.SaveChanges();
            }
            return studentToUpdate;
        }

        public Student DeleteById(int id)
        {
            Student studentToDelete = null;
            using (var database = new StudentManagerDatabaseFirstEntities())
            {
                studentToDelete = database.Student.Where(x => x.Id == id).FirstOrDefault();
                database.Student.Remove(studentToDelete);
                database.SaveChanges();
            }
            return studentToDelete;
        }
    }
}

