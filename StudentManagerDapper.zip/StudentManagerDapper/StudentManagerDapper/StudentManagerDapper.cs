﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace StudentManagerDapper
{
    public class StudentManagerDapper
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public List<Student> GetAll()
        {
            using (var connection = new SqlConnection(Resources.ConnectionString))
            {
                try
                {
                    return SqlMapper.Query<Student>(connection, "SELECT * FROM Student").ToList();
                }
                catch (ArgumentNullException ex)
                {
                    log.Error(ex);
                    throw;
                }
            }
        }

        public Student Create(Student student)
        {

            using (var connection = new SqlConnection(Resources.ConnectionString))
            {
                try
                {
                    var id = SqlMapper.Query<int>(connection, "INSERT INTO Student VALUES (@Name, @Lastname, @Birthday);SELECT CAST(SCOPE_IDENTITY() AS INT);",
                        new { @Name = student.Name, @Lastname = student.Lastname, @Birthday = student.BirthDate }).Single();

                    return SqlMapper.Query<Student>(connection, "SELECT * FROM Student WHERE Id = @Id", new { @Id = id }).Single();
                }
                catch (InvalidOperationException e)
                {
                    log.Error(e);
                    throw;
                }
                catch (ArgumentNullException e)
                {
                    log.Error(e);
                    throw;
                }
            }


        }

        public Student Update(Student student)
        {
            using (var connection = new SqlConnection(Resources.ConnectionString))
            {
                
                    connection.Query<Student>("UPDATE Student SET Name = @Name, Lastname = @Lastname, Birthday = @BirthDate WHERE Id = @Id;",
                            new { @Name = student.Name, @Lastname = student.Lastname, @BirthDate = student.BirthDate, @Id = student.Id });
                try
                {
                    var updatedStudent = SqlMapper.Query<Student>(connection, "SELECT * FROM Student WHERE Id = @Id", new { @Id = student.Id }).Single();

                    return updatedStudent;
                }
                catch (ArgumentNullException e)
                {
                    log.Error(e);
                    throw;
                }
                catch(InvalidOperationException e)
                {
                    log.Error(e);
                    throw;
                }
            }
        }

        public bool DeleteById(int id)
        {
            using (var connection = new SqlConnection(Resources.ConnectionString))
            {
                SqlMapper.Query<bool>(connection, "DELETE FROM Student WHERE Id = @Id", new { @Id = id });

                return true;
            }
        }


    }
}
